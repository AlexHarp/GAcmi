<?php

namespace Drupal\multiversion\Entity\Index;

interface UuidIndexInterface extends EntityIndexInterface { }
