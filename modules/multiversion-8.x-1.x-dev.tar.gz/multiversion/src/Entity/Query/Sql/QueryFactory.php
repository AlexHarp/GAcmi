<?php

namespace Drupal\multiversion\Entity\Query\Sql;

use Drupal\Core\Entity\Query\Sql\QueryFactory as CoreQueryFactory;

class QueryFactory extends CoreQueryFactory { }
